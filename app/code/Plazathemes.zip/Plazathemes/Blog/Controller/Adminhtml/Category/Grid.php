<?php
/**
 * Copyright © 2015 PlazaThemes.com. All rights reserved.

 * @author PlazaThemes Team <contact@plazathemes.com>
 */

namespace Plazathemes\Blog\Controller\Adminhtml\Category;

/**
 * Blog category grid controller
 */
class Grid extends \Plazathemes\Blog\Controller\Adminhtml\Category
{

}

<?php
/**
 * Copyright © 2015 PlazaThemes.com. All rights reserved.

 * @author PlazaThemes Team <contact@plazathemes.com>
 */

namespace Plazathemes\Blog\Controller\Adminhtml\Category;

/**
 * Blog category list controller
 */
class Index extends \Plazathemes\Blog\Controller\Adminhtml\Category
{

}

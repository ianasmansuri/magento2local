<?php
/**
* Copyright © 2015 PlazaThemes.com. All rights reserved.

* @author PlazaThemes Team <contact@plazathemes.com>
*/

namespace Plazathemes\Testimonial\Block\Adminhtml\Testimo\Edit\Tab;

use Plazathemes\Testimonial\Model\Status;

class Testimo extends \Magento\Backend\Block\Widget\Form\Generic
 implements \Magento\Backend\Block\Widget\Tab\TabInterface {
	/**
	 * @var \Magento\Framework\ObjectFactory
	 */
	protected $_objectFactory;

	/**
	 * @var \Magento\Store\Model\System\Store
	 */
	protected $_systemStore;

	/**
	 * helper
	 * @var \Plazathemes\Testimonial\Helper\Data
	 */
	protected $_testimonialHelper;

	/**
	 * @var \Plazathemes\Testimonial\Model\Testimo
	 */
	protected $_testimo;

	/**
	 * [__construct description]
	 * @param \Magento\Backend\Block\Template\Context    $context            [description]
	 * @param \Plazathemes\Testimonial\Helper\Data        $testimonialHelper [description]
	 * @param \Magento\Framework\Registry                $registry           [description]
	 * @param \Magento\Framework\Data\FormFactory        $formFactory        [description]
	 * @param \Magento\Store\Model\System\Store          $systemStore        [description]
	 * @param \Magento\Framework\ObjectFactory           $objectFactory      [description]
	 * @param \Plazathemes\Testimonial\Model\Testimo       $testimo             [description]
	 * @param array                                      $data               [description]
	 */
	public function __construct(
		\Magento\Backend\Block\Template\Context $context,
		\Plazathemes\Testimonial\Helper\Data $testimonialHelper,
		\Magento\Framework\Registry $registry,
		\Magento\Framework\Data\FormFactory $formFactory,
		\Magento\Store\Model\System\Store $systemStore,
		\Plazathemes\Testimonial\Model\Testimo $testimo,
		array $data = []
	) {
		$this->_localeDate = $context->getLocaleDate();
		$this->_systemStore = $systemStore;
		$this->_testimonialHelper = $testimonialHelper;
		$this->_testimo = $testimo;
		parent::__construct($context, $registry, $formFactory, $data);
	}

	protected function _prepareLayout() {
		$this->getLayout()->getBlock('page.title')->setPageTitle($this->getPageTitle());

		\Magento\Framework\Data\Form::setFieldsetElementRenderer(
			$this->getLayout()->createBlock(
				'Plazathemes\Testimonial\Block\Adminhtml\Form\Renderer\Fieldset\Element',
				$this->getNameInLayout() . '_fieldset_element'
			)
		);
	}

	/**
	 * Prepare form
	 *
	 * @return $this
	 */
	protected function _prepareForm() {
		$model = $this->_coreRegistry->registry('testimo');

		// $storeViewId = $this->getRequest()->getParam('store');
		
		/** @var \Magento\Framework\Data\Form $form */
		$form = $this->_formFactory->create();

		$form->setHtmlIdPrefix($this->_testimo->getFormFieldHtmlIdPrefix());

		$fieldset = $form->addFieldset('base_fieldset', ['legend' => __('Testimonial Information')]);

		if ($model->getId()) {
			$fieldset->addField('testimo_id', 'hidden', ['name' => 'testimo_id']);
		}

		$elements = [];
		$elements['name'] = $fieldset->addField(
			'name',
			'text',
			[
				'name' => 'name',
				'label' => __('Name'),
				'title' => __('Name'),
				'required' => true,
			]
		);
		
		$elements['job'] = $fieldset->addField(
			'job',
			'text',
			[
				'name' => 'job',
				'label' => __('Job'),
				'title' => __('Job'), 
			]
		);
		/**
         * Check is single store mode
         */
		
        $elements['store_id'] = $fieldset->addField(
			'store_id',
			'multiselect',
			[
				'name' => 'stores[]',
				'label' => __('Store View'),
				'title' => __('Store View'),
				'required' => true,
				'values' => $this->_systemStore->getStoreValuesForForm(false, true),
			]
		);
		
		$elements['email'] = $fieldset->addField(
			'email',
			'text',
			[
				'title' => __('Email'),
				'label' => __('Email'),
				'name' => 'email',
				'required' => true,
			]
		);
		
		$elements['avatar'] = $fieldset->addField(
			'avatar',
			'image',
			[
				'title' => __('Avatar'),
				'label' => __('Avatar'),
				'name' => 'avatar',
				'note' => 'Allow image type: jpg, jpeg, gif, png',
				'required' => true,
			]

		);
		
		$elements['website'] = $fieldset->addField(
			'website',
			'text',
			[
				'title' => __('Website'),
				'label' => __('Website'),
				'name' => 'website',
			]
		);
		
		$elements['company'] = $fieldset->addField(
			'company',
			'text',
			[
				'title' => __('Company'),
				'label' => __('Company'),
				'name' => 'company',
			]
		);
		
		$elements['address'] = $fieldset->addField(
			'address',
			'text',
			[
				'title' => __('Address'),
				'label' => __('Address'),
				'name' => 'address',
			]
		);
		
		$elements['testimonial'] = $fieldset->addField(
			'testimonial',
			'textarea',
			[
				'title' => __('Testimonial'),
				'label' => __('Testimonial'),
				'name' => 'testimonial',
				'required' => true,
			]
		);
		
		$elements['status'] = $fieldset->addField(
			'status',
			'select',
			[
				'label' => __('Status'),
				'title' => __('Testimonial Status'),
				'name' => 'status',
				'options' => Status::getAvailableStatuses(),
			]
		);
		
		$elements['order'] = $fieldset->addField(
			'order',
			'text',
			[
				'name' => 'order',
				'label' => __('Order'),
				'title' => __('Order'),
			]
		);
		
		
		$this->_eventManager->dispatch('adminhtml_cms_page_edit_tab_main_prepare_form', ['form' => $form]);
		
		$form->setValues($model->getData());
		$this->setForm($form);

		return parent::_prepareForm();
	}

	public function getTestimo() {
		return $this->_coreRegistry->registry('testimo');
	}

	public function getPageTitle() {
		// return $this->getTestimo()->getId() ? __("Edit Testimonial '%1'", $this->escapeHtml($this->getTestimo()->getName())) : __('New Testimonial');
	}

	/**
	 * Prepare label for tab
	 *
	 * @return string
	 */
	public function getTabLabel() {
		return __('Testimonial Information');
	}

	/**
	 * Prepare title for tab
	 *
	 * @return string
	 */
	public function getTabTitle() {
		return __('Testimonial Information');
	}

	/**
	 * {@inheritdoc}
	 */
	public function canShowTab() {
		return true;
	}

	/**
	 * {@inheritdoc}
	 */
	public function isHidden() {
		return false;
	}

	/**
	 * Check permission for passed action
	 *
	 * @param string $resourceId
	 * @return bool
	 */
	protected function _isAllowedAction($resourceId) {
		return $this->_authorization->isAllowed($resourceId);
	}
}

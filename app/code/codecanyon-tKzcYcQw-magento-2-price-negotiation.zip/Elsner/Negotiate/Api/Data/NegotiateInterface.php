<?php

namespace Elsner\Negotiate\Api\Data;
 
interface NegotiateInterface
{
    /**
     * Constants for keys of data array. Identical to the name of the getter in snake case.
     */
    const ID = 'id';
    const PRODUCT_ID = 'product_id';
    const PRODUCT_NAME = 'product_name';
    const PRODUCT_PRICE = 'product_price';
    const FIRSTNAME = 'firstname';
    const LASTNAME = 'lastname';
    const EMAIL = 'email';
    const TELEPHONE = 'telephone';
    const REQUESTED_PRICE = 'requested_price';
    const REQUESTED_QUANTITY = 'requested_quantity';
    const NOTE = 'note';
    const COUPON_CODE = 'coupon_code';
    const STATUS = 'status';
    public function getId();
 
    public function setId($id);

    public function getProductId();

    public function setProductId($productid);

    public function getProductName();

    public function setProductName($productname);

    public function getProductPrice();

    public function setProductPrice($productprice);

    public function getFirstname();

    public function setFirstname($firstname);
 
    public function getlastname();

    public function setlastname($lastname);

    public function getEmail();

    public function setEmail($email);

    public function getTelephone();
 
    public function setTelephone($telephone);

    public function getRequestedPrice();

    public function setRequestedPrice($requestedprice);

    public function getRequestedQuantity();

    public function setRequestedQuantity($requestedquantity);

    public function getNote();

    public function setNote($note);

    public function getCouponCode();

    public function setCouponCode($couponcode);

    public function getStatus();

    public function setStatus($status);
}

<?php

namespace Elsner\Negotiate\Model\ResourceModel\Negotiate;
 
class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    
    protected $_idFieldName = 'id';
    
    protected function _construct()
    {
        $this->_init('Elsner\Negotiate\Model\Negotiate', 'Elsner\Negotiate\Model\ResourceModel\Negotiate');
    }
}

<?php

namespace Elsner\Negotiate\Controller\Adminhtml\Negotiate;

class Accept extends \Magento\Backend\App\Action
{
    protected $_storeManager;
    protected $_resultPageFactory;

    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        parent::__construct($context);
        $this->_resultPageFactory = $resultPageFactory;
        $this->_storeManager = $storeManager;
    }

    public function execute()
    {
        $objDate = $this->_objectManager->create('Magento\Framework\Stdlib\DateTime\DateTime');
        $date = $objDate->gmtDate('Y-m-d');
        $rowId = (int) $this->getRequest()->getParam('id');
        $rowData = $this->_objectManager->create('Elsner\Negotiate\Model\Negotiate');

        $websites = $this->_storeManager->getWebsites();
        $websitesIds = array();
        foreach ($websites as $website) {
            $websitesIds[] = $website->getId();
        }

        if ($rowId) {
             $rowData = $rowData->load($rowId);
             if($rowData->getRequestedPrice() != $rowData->getRequestedPriceOld())
             {
               $this->messageManager->addError(__('Sorry You can "Re-offer" after editing it..'));
               $this->_redirect('negotiate/negotiate/index');
             }
             else
             {

             $proPrice=$rowData->getProductPrice();
             $reqPrice=$rowData->getRequestedPrice();
             $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
             $pass = []; //remember to declare $pass as an array
             $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
              for ($i = 0; $i < 12; $i++) {
                $n = rand(0, $alphaLength);
                $pass[] = $alphabet[$n];
            }
             $code=implode($pass);
             $discount= ($proPrice - $reqPrice) * $rowData->getRequestedQuantity();
             $product = $this->_objectManager->get('Magento\Catalog\Model\Product')->load($rowData->getProductId());
             $sku=$product->getSku();
             $shoppingCartPriceRule = $this->_objectManager->create('Magento\SalesRule\Model\Rule');
             $shoppingCartPriceRule->setName('Price Negotiation discount rule for - ' . $sku)
            ->setDescription('Price Negotiation Rule')
            ->setFromDate($date)
            ->setToDate(null)
            ->setUsesPerCustomer('0')
            ->setCustomerGroupIds(array('0','1','2','3',))
            ->setIsActive('1')
            ->setStopRulesProcessing('0')
            ->setIsAdvanced('1')
            ->setProductIds(null)
            ->setSortOrder('1')
            ->setSimpleAction('cart_fixed')
            ->setDiscountAmount($discount)
            ->setDiscountQty(null)
            ->setDiscountStep('0')
            ->setSimpleFreeShipping('0')
            ->setApplyToShipping('0')
            ->setTimesUsed('0')
            ->setIsRss('0')
            ->setWebsiteIds($websitesIds)
            ->setCouponType('2')
            ->setCouponCode($code)
            ->setUsesPerCoupon(1);
            $item_found = $this->_objectManager->create('Magento\SalesRule\Model\Rule\Condition\Product\Found')
            ->setType('Magento\SalesRule\Model\Rule\Condition\Product\Found')
            ->setValue(1) // 1 == FOUND
            ->setAggregator('all'); // match ALL conditions
            $shoppingCartPriceRule->getConditions()->addCondition($item_found);
            $conditions = $this->_objectManager->create('Magento\SalesRule\Model\Rule\Condition\Product')
            ->setType('Magento\SalesRule\Model\Rule\Condition\Product')
            ->setAttribute('sku')
            ->setOperator('==')
            ->setValue($sku);
            $item_found->addCondition($conditions);

             $actions = $this->_objectManager->create('Magento\SalesRule\Model\Rule\Condition\Product')
            ->setType('Magento\SalesRule\Model\Rule\Condition\Product')
            ->setAttribute('sku')
            ->setOperator('==')
            ->setValue($sku);
             $shoppingCartPriceRule->getActions()->addCondition($actions);

            $qtyCond = $this->_objectManager->create('Magento\SalesRule\Model\Rule\Condition\Product')
            ->setType('Magento\SalesRule\Model\Rule\Condition\Product')
            ->setAttribute('quote_item_qty')
            ->setOperator('==')
            ->setValue($rowData->getRequestedQuantity());
            $shoppingCartPriceRule->getActions()->addCondition($qtyCond);
            $shoppingCartPriceRule->save();
            $rowData->setStatus(1);
            $rowData->setCouponCode($code);
            $rowData->save();

            /*Email Code*/
                $currencysymbol = $this->_objectManager->get('Magento\Directory\Model\Currency');
                $emailTemplateVariables = [];
                $emailTempVariables['name'] = $rowData->getFirstname().' '.$rowData->getLastName();
                $emailTempVariables['price'] = $currencysymbol->getCurrencySymbol().$rowData->getRequestedPrice();
                $emailTempVariables['code'] = $code;
                $emailTempVariables['subject'] = 'Elsner Negotiate Accepted';

                $postObject = new \Magento\Framework\DataObject();
                $postObject->setData($emailTempVariables);

                $from = [
                            'name' =>'Price Negotiate Mail',
                            'email' => 'sales@testmail.com',
                            ];
                $email=$rowData->getEmail();
                $_transportBuilder=$this->_objectManager->create('Magento\Framework\Mail\Template\TransportBuilder');
                $transport = $_transportBuilder->setTemplateIdentifier('accept_email_template')
                ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID])
                ->setTemplateVars(['data' => $postObject])
                ->setFrom($from)
                ->addTo($email)
                ->setReplyTo($rowData->getEmail())           
                ->getTransport();              
                $transport->sendMessage();
                $this->messageManager->addSuccess(__('The Coupon code Created successfully'));
             }
        }
        $this->_redirect('negotiate/negotiate/index');
    }
}

<?php

namespace Elsner\Negotiate\Controller\Adminhtml\Negotiate;
 
class ReOffer extends \Magento\Backend\App\Action
{
    
    protected $_resultPageFactory;
 
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->_resultPageFactory = $resultPageFactory;
    }

    public function execute()
     {
        $rowId = (int) $this->getRequest()->getParam('id');
        $storeManager = $this->_objectManager->get('\Magento\Store\Model\StoreManagerInterface');
        $acceptUrl= $storeManager->getStore()->getBaseUrl().'negotiate/negotiate/accept/id/'.$rowId;
        $rowData = $this->_objectManager->create('Elsner\Negotiate\Model\Negotiate');
        if ($rowId) {
             $rowData = $rowData->load($rowId);
             if($rowData->getRequestedPrice() == $rowData->getRequestedPriceOld())
             {
               $this->messageManager->addError(__('Sorry Requested Price and Re-offer Price are same..'));
               $this->_redirect('negotiate/negotiate/index');
             }
             else
             {

             $product = $this->_objectManager->get('Magento\Catalog\Model\Product')->load($rowData->getProductId());
             $rowData->setStatus(2);
             $rowData->save();
             $currencysymbol = $this->_objectManager->get('Magento\Directory\Model\Currency');
             $emailTemplateVariables = [];
                $emailTempVariables['name'] = $rowData->getFirstname().' '.$rowData->getLastName();
                $emailTempVariables['price'] = $currencysymbol->getCurrencySymbol().$rowData->getRequestedPrice();
                $emailTempVariables['priceold'] = $currencysymbol->getCurrencySymbol().$rowData->getRequestedPriceOld();
                $emailTempVariables['producturl'] = $product->getProductUrl();
                $emailTempVariables['accepturl'] = $acceptUrl;
                $emailTempVariables['subject'] = 'Elsner Negotiate Reoffered';

                $postObject = new \Magento\Framework\DataObject();
                $postObject->setData($emailTempVariables);

                 $from = [
                            'name' =>'Price Negotiate Mail',
                            'email' => 'sales@testmail.com',
                            ];
                 $email=$rowData->getEmail();
                 $_transportBuilder=$this->_objectManager->create('Magento\Framework\Mail\Template\TransportBuilder');
                 $transport = $_transportBuilder->setTemplateIdentifier('reoffer_email_template')
                 ->setTemplateOptions(['area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                 'store' => \Magento\Store\Model\Store::DEFAULT_STORE_ID])
                 ->setTemplateVars(['data' => $postObject])
                 ->setFrom($from)
                 ->addTo($email)
                 ->setReplyTo($rowData->getEmail())            
                 ->getTransport();
                 $transport->sendMessage();
                 $this->messageManager->addSuccess(__('Status Changed Succesfully'));
             }
        }
        $this->_redirect('negotiate/negotiate/index');
     }
}

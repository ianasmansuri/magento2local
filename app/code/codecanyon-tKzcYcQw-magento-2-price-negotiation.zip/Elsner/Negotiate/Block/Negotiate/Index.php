<?php
namespace Elsner\Negotiate\Block\Negotiate;
use Magento\Framework\View\Element\Template\Context;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\View\Element\Template;
class Index extends Template
{
	protected $objectManager;
	protected $_storeManager;

	  public function __construct(
         \Magento\Framework\ObjectManagerInterface $objectManager,
         \Magento\Store\Model\StoreManagerInterface $storeManager,
         Context $context,
         array $data = []
         ) {
	  		 $this->objectManager = $objectManager;
	  		 $this->_storeManager = $storeManager;
        	parent::__construct($context, $data);
	  }
	 protected  function _construct()
    {
        parent::_construct();
        $customerSession = $this->objectManager->get('Magento\Customer\Model\Session'); 
	    $collection = $this->objectManager->create('Elsner\Negotiate\Model\ResourceModel\Negotiate\Collection');
	    $collection->addFieldToFilter('email',$customerSession->getCustomer()->getEmail());
        $this->setCollection($collection);
    }
    protected function _prepareLayout()
    {
    	$negotiate_num=$this->objectManager->create('Elsner\Negotiate\Helper\Data')->getConfig('negotiate/general/list');
        parent::_prepareLayout();
        if ($this->getCollection()){
            $pager = $this->getLayout()->createBlock('Magento\Theme\Block\Html\Pager');
            $pager->setLimit($negotiate_num)->setShowAmounts(false)->setCollection($this->getCollection());
            $this->setChild('pager', $pager);
            $this->getCollection()->load();
        }
       return $this;
    }
    public function getPagerHtml()
    {
       return $this->getChildHtml('pager');
    }
}

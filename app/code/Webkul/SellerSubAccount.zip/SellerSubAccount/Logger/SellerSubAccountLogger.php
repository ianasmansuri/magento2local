<?php
/**
 * Webkul Software
 *
 * @category Webkul
 * @package Webkul_Mangopay
 * @author Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license https://store.webkul.com/license.html
 */

namespace Webkul\SellerSubAccount\Logger;

class SellerSubAccountLogger extends \Monolog\Logger
{
    
}

<?php
/**
 * @category   Webkul
 * @package    Webkul_MpAdvancedCommission
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c)  Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MpAdvancedCommission\Controller\Adminhtml\CommissionRules;

class Grid extends Index
{
    /**
     * set page data
     *
     * @return $this
     */
    protected function setPageData()
    {
        return $this;
    }
}

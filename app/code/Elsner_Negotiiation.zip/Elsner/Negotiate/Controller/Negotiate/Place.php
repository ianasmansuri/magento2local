<?php
namespace Elsner\Negotiate\Controller\Negotiate;

use Magento\Framework\Controller\ResultFactory;

class Place extends \Magento\Framework\App\Action\Action
{
    
    public function execute()
    {
        $data = $this->getRequest()->getParams();
        $proPrice = $data['product_price'];
        $requestedPrice = $data['requested_price'];
        if ($data) {
            if($requestedPrice < $proPrice){
                $model = $this->_objectManager->create('Elsner\Negotiate\Model\Negotiate');
                $id = $this->getRequest()->getParam('id');
                if ($id) {
                    $model->load($id);
                }
                $model->setData($data);
                $model->setRequestedPriceOld($data['requested_price']);
                try {
                    $model->save();
                    $this->messageManager->addSuccess(__('Thank You ... Your Request Submitted Successfully..'));
                } catch (\Magento\Framework\Model\Exception $e) {
                    $this->messageManager->addError($e->getMessage());
                }
                $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
                $resultRedirect->setUrl($this->_redirect->getRefererUrl());
                return $resultRedirect;
            }
            else{
                $this->messageManager->addError(__('Requested Price should be less then product price'));
                $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
                $resultRedirect->setUrl($this->_redirect->getRefererUrl());
                return $resultRedirect;
            }

        }
    }
}

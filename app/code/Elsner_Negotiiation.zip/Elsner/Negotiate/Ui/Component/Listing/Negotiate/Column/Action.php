<?php
 
namespace Elsner\Negotiate\Ui\Component\Listing\Negotiate\Column;
 
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\UrlInterface;
 
class Action extends Column
{
    /** Url path */
    const ROW_ACCEPT_URL = 'negotiate/negotiate/accept';
     const ROW_REOFFER_URL = 'negotiate/negotiate/reoffer';
    const ROW_REJECT_URL = 'negotiate/negotiate/reject';
    /** @var UrlInterface */
    protected $_urlBuilder;

    private $_acceptUrl;

    private $_reofferUrl;

    private $_rejectUrl;
   
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
        array $components = [],
        array $data = [],
        $acceptUrl = self::ROW_ACCEPT_URL,
        $reofferUrl = self::ROW_REOFFER_URL,
        $rejectUrl = self::ROW_REJECT_URL
    ) {
        $this->_urlBuilder = $urlBuilder;
        $this->_acceptUrl = $acceptUrl;
        $this->_reofferUrl = $reofferUrl;
        $this->_rejectUrl = $rejectUrl;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }
 
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                $name = $this->getData('name');
                if (isset($item['id'])) {
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                $data = $objectManager->get('Elsner\Negotiate\Model\Negotiate')->load($item['id']);
                if($data['status'] == 1)
                {

                    $item[$name]['reject'] = [
                        'href' => $this->_urlBuilder->getUrl(
                            $this->_rejectUrl,
                            ['id' => $item['id']]
                        ),
                        'label' => __('Reject'),
                         'confirm' => [
                            'message' => __('Are you sure you wan\'t to continue?')
                         ]
                    ];
                }
                elseif($data['status'] == 2 && $data['coupon_code'])
                {
                    $item[$name]['reject'] = [
                        'href' => $this->_urlBuilder->getUrl(
                            $this->_rejectUrl,
                            ['id' => $item['id']]
                        ),
                        'label' => __('Reject'),
                         'confirm' => [
                            'message' => __('Are you sure you wan\'t to continue?')
                         ]
                    ];
                }
                elseif($data['status'] != 3)
                {
                     $item[$name]['accept'] = [
                        'href' => $this->_urlBuilder->getUrl(
                            $this->_acceptUrl,
                            ['id' => $item['id']]
                        ),
                        'label' => __('Accept'),
                        'confirm' => [
                            'message' => __('Are you sure you wan\'t to continue?')
                        ]
                    ];
                    $item[$name]['reoffer'] = [
                        'href' => $this->_urlBuilder->getUrl(
                            $this->_reofferUrl,
                            ['id' => $item['id']]
                        ),
                        'label' => __('Re-Offer'),
                         'confirm' => [
                            'message' => __('Are you sure you wan\'t to continue?')
                         ]
                    ];
                    $item[$name]['reject'] = [
                        'href' => $this->_urlBuilder->getUrl(
                            $this->_rejectUrl,
                            ['id' => $item['id']]
                        ),
                        'label' => __('Reject'),
                         'confirm' => [
                            'message' => __('Are you sure you wan\'t to continue?')
                         ]
                    ];
                }
            }

        }
    }
 
        return $dataSource;
    }
}

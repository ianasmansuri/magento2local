<?php

namespace Elsner\Negotiate\Model;
 
use Elsner\Negotiate\Api\Data\NegotiateInterface;
 
class Negotiate extends \Magento\Framework\Model\AbstractModel implements NegotiateInterface
{
    
    const CACHE_TAG = 'elsner_negotiate';
    
    protected $_cacheTag = 'elsner_negotiate';
   
    protected $_eventPrefix = 'elsner_negotiate';
 
    protected function _construct()
    {
        $this->_init('Elsner\Negotiate\Model\ResourceModel\Negotiate');
    }
 
    public function getId()
    {
        return $this->getData(self::ID);
    }

    public function setId($id)
    {
        return $this->setData(self::ID, $id);
    }
 
    public function getProductId()
    {
        return $this->getData(self::PRODUCT_ID);
    }

    public function setProductId($productid)
    {
        return $this->setData(self::PRODUCT_ID, $productid);
    }

    public function getProductName()
    {
        return $this->getData(self::PRODUCT_NAME);
    }

    public function setProductName($productname)
    {
        return $this->setData(self::PRODUCT_NAME, $productname);
    }

    public function getProductPrice()
    {
        return $this->getData(self::PRODUCT_PRICE);
    }

    public function setProductPrice($productprice)
    {
        return $this->setData(self::PRODUCT_PRICE, $productprice);
    }

    public function getFirstname()
    {
        return $this->getData(self::FIRSTNAME);
    }

    public function setFirstname($firstname)
    {
        return $this->setData(self::FIRSTNAME, $firstname);
    }

    public function getlastname()
    {
        return $this->getData(self::LASTNAME);
    }

    public function setlastname($lastname)
    {
        return $this->setData(self::LASTNAME, $lastname);
    }

    public function getEmail()
    {
        return $this->getData(self::EMAIL);
    }

    public function setEmail($email)
    {
        return $this->setData(self::EMAIL, $email);
    }

    public function getTelephone()
    {
        return $this->getData(self::TELEPHONE);
    }

    public function setTelephone($telephone)
    {
        return $this->setData(self::TELEPHONE, $telephone);
    }
 
    public function getRequestedPrice()
    {
        return $this->getData(self::REQUESTED_PRICE);
    }
 
    public function setRequestedPrice($requestedprice)
    {
        return $this->setData(self::REQUESTED_PRICE, $requestedprice);
    }

    public function getRequestedQuantity()
    {
        return $this->getData(self::REQUESTED_QUANTITY);
    }

    public function setRequestedQuantity($requestedquantity)
    {
        return $this->setData(self::REQUESTED_QUANTITY, $requestedquantity);
    }

    public function getNote()
    {
        return $this->getData(self::NOTE);
    }

    public function setNote($note)
    {
        return $this->setData(self::NOTE, $note);
    }

    public function getCouponCode()
    {
        return $this->getData(self::COUPON_CODE);
    }

    public function setCouponCode($couponcode)
    {
        return $this->setData(self::COUPON_CODE, $couponcode);
    }

    public function getStatus()
    {
        return $this->getData(self::STATUS);
    }

    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }
}

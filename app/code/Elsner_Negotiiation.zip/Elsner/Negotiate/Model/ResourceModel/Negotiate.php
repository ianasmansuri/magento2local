<?php

namespace Elsner\Negotiate\Model\ResourceModel;
 
class Negotiate extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    
    protected $_idFieldName = 'id';
   
    protected function _construct()
    {
        $this->_init('elsner_negotiate', 'id');
    }
}
